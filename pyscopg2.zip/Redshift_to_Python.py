import psycopg2

#Obtaining the connection to RedShift
con=psycopg2.connect(dbname= 'dev', host='redshift-cluster-1.c2nh0wlf4z7g.ap-southeast-2.redshift.amazonaws.com',
port= '5439', user= 'awsuser', password= 'Rabbithole1234$#')

#Opening a cursor and running a query
cur = con.cursor()
cur.execute("SELECT SYSDATE;")
#Printing the output
print(cur.fetchall())
cur.close()
con.close()
