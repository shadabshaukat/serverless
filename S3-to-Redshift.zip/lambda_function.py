#######################################################################################
# Author         :      Shadab Mohammad
# Create Date    :      13-05-2019
# Modified Date  :      26-09-2019
# Name           :      Load Dataset from AWS S3 bucket to your Redshift Cluster
# Dependencies   :      Requires Python 3.6+. Python Libraries required 'psycopg2'
#######################################################################################
import psycopg2
import csv
import time
import sys
import os
import datetime
from datetime import date
datetime_object = datetime.datetime.now()


print ("###### Load Data From S3 to Redshift ######")
print ("")
print ("Start TimeStamp")
print ("---------------")
print(datetime_object)
print ("")

def lambda_handler(event, context):
        #Obtaining the connection to RedShift
    con=psycopg2.connect(dbname= 'testdb', host='shadmha-us-east-2.crhzd8dtwytq.us-east-2.redshift.amazonaws.com', port= '5439', user= 'awsuser', password= 'Awsuser1234')

    copy_command_1="copy connection_log from 's3://shadmha-us-east-2/cross-acct-test/connection_events.csv' delimiter ',' csv iam_role 'arn:aws:iam::241135536116:role/RoleA,arn:aws:iam::804739925711:role/RoleB' ignoreheader 1;"

    #Opening a cursor and run truncate query
    cur = con.cursor()
    query= f'''
    DROP TABLE IF EXISTS connection_log CASCADE;

    CREATE TABLE connection_log(
    username varchar(50),
    event varchar(50),
    count int8);
    COMMIT;'''
    cur.execute(query)
    con.commit()

    #Opening a cursor and run copy query
    cur.execute(copy_command_1)
    con.commit()
    #Close the cursor and the connection
    cur.close()
    con.close()

    # Progress Bar Code Ends here

    datetime_object_2 = datetime.datetime.now()
    print ("End TimeStamp")
    print ("-------------")
    print (datetime_object_2)
    print ("")
